Download the Ubuntu Server LTS 16.04 image (ISO) via:
[http://workshops.pmplabs.com/wordpress/images/ubuntu-16.04.2-server-amd64.iso](http://workshops.pmplabs.com/wordpress/images/ubuntu-16.04.2-server-amd64.iso)
