Bootstrap Canvas WP WordPress theme, Copyright 2014 - 2016 Schon Garcia
Bootstrap Canvas WP WordPress theme is licensed under the GPL.

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program. If not, see < http://www.gnu.org/licenses/ >.

Bootstrap Canvas WP Theme bundles the following third-party resources:

Bootstrap, Copyright (c) 2011 - 2016 Twitter, Inc.
Bootstrap is licensed under MIT
Source: http://getbootstrap.com

HTML5 Shiv, Copyright (c) 2014 Alexander Farkas
html5shiv.js is licensed under MIT and GPL2
Source: https://github.com/aFarkas/html5shiv/

IE10 viewport hack for Surface/desktop Windows 8 bug, Copyright (c) 2014 Twitter, Inc.
ie10-viewport-bug-workaround.js is licensed under CC BY 3.0 US
Source: http://getbootstrap.com

Respond, Copyright (c) 2012 Scott Jehl
respond.js is licensed under MIT
Source: https://github.com/scottjehl/Respond/