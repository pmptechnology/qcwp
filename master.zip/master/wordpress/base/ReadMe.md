Download the Open Virtual Machine Archive (OVA) Base Image for this workshop via:
[http://workshops.pmplabs.com/wordpress/wordpress/base/ubuntu-wordpress-server-pmp-technology.ova](http://workshops.pmplabs.com/wordpress/wordpress/base/ubuntu-wordpress-server-pmp-technology.ova)
