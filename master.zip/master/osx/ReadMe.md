Download Virtual Box for OS X via:
[http://workshops.pmplabs.com/wordpress/osx/VirtualBox-5.1.18-114002-OSX.dmg](http://workshops.pmplabs.com/wordpress/osx/VirtualBox-5.1.18-114002-OSX.dmg)
