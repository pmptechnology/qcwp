Download Virtual Box for Windows via:
[http://workshops.pmplabs.com/wordpress/windows/VirtualBox-5.1.18-114002-Win.exe](http://workshops.pmplabs.com/wordpress/windows/VirtualBox-5.1.18-114002-Win.exe)
