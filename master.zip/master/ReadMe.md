To get started view the latest [handout](https://github.com/pmptechnology/wpqc/blob/master/documentation/handout_v1.pdf) for this workshop.
